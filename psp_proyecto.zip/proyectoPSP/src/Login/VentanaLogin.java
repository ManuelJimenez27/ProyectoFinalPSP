package Login;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class VentanaLogin extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader cargador = new FXMLLoader(getClass().getResource("../Login/layout_login.fxml"));
        Parent root = cargador.load();
        stage.setScene(new Scene(root, 600, 150));
        stage.show();
    }

    public void iniciador(){
        this.launch();
    }

}
