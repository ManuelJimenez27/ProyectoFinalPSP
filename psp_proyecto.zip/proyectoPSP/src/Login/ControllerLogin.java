package Login;

import App.Interface;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import proyectopsp.BaseDeDatos;
import proyectopsp.Programa;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ControllerLogin implements Initializable {

    @FXML
    Button entrar, salir;

    @FXML
    TextField contra, usuario;

    private BaseDeDatos bd;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        bd = new BaseDeDatos();
        entrar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String usuarioText = usuario.getText();
                String contraText = bd.SHA512(contra.getText(), "descoloke");
                try {
                    if(bd.acceder(usuarioText, contraText)){
                        Interface inter = new Interface();
                        Stage stage = (Stage) contra.getScene().getWindow();
                        stage.hide();

                        Programa p = new Programa();
                        p.start();
                    }else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("ERROR");
                        alert.showAndWait();

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });

    }
}
