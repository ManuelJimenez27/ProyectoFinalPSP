import Login.VentanaLogin;
import proyectopsp.BaseDeDatos;

public class Main {

    public static void main(String[] args) {
        VentanaLogin login = new VentanaLogin();
        login.iniciador();
    }

}
