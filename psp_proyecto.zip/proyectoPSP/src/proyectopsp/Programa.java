/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectopsp;

import App.Interface;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * @author manuel
 */
public class Programa extends Thread {

    private int r;
    private int g;
    private int b;
    private boolean salirBucle = false;
    private ArrayList<Colores> coloresLeidos = new ArrayList<>();

    @Override
    public void run() {

        Robot bot = null;
        try {
            bot = new Robot();
        } catch (AWTException ex) {

        }

        Interface.enviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(coloresLeidos.size());
                salirBucle = true;
                int r = 0, g = 0, b = 0;
                for (int i = 0; i < coloresLeidos.size(); i++) {
                    r += coloresLeidos.get(i).getR();
                    g += coloresLeidos.get(i).getG();
                    b += coloresLeidos.get(i).getB();
                }
                r = r / coloresLeidos.size();
                g = g / coloresLeidos.size();
                b = b / coloresLeidos.size();
                Color colorMedio = new Color(r, g, b);
                EnviarAServidor enviar = new EnviarAServidor(colorMedio);

                System.exit(0);
            }
        });
        int i = 0;
        while (!salirBucle) {
            int x;
            int y;
            x = MouseInfo.getPointerInfo().getLocation().x;
            y = MouseInfo.getPointerInfo().getLocation().y;
            Color color = bot.getPixelColor(x, y);
            r = color.getRed();
            g = color.getGreen();
            b = color.getBlue();
            //System.out.println(color.getRed() + " " + color.getGreen() + " " + color.getBlue());
            Interface.panel.setBackground(new Color(r, g, b));
            Interface.etiqueta.setText(color.getRed() + " " + color.getGreen() + " " + color.getBlue());

            if (i == 10) {
                coloresLeidos.add(new Colores(r, g, b));
                i = 0;
            }
            i++;
        }
    }

}
