package proyectopsp;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class EnviarAServidor extends Thread {
    Color colorMedia;

    public EnviarAServidor(Color colorMedia) {
        this.colorMedia = colorMedia;

        try {
            String Host = "localhost";
            int puerto = 5556;//puerto remoto

            // Propiedades JSSE)
            System.setProperty("javax.net.ssl.trustStore","src/AlmacenSrv");
            System.setProperty("javax.net.ssl.trustStorePassword","1234567");


            SSLSocketFactory sfact = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket Cliente  = (SSLSocket) sfact.createSocket(Host, puerto);

            // CREO FLUJO DE SALIDA AL SERVIDOR
            DataOutputStream flujoSalida = new DataOutputStream(Cliente.getOutputStream());

            // ENVIO UN SALUDO AL SERVIDOR
            flujoSalida.writeUTF(colorMedia.getRed() + "," + colorMedia.getGreen() + "," + colorMedia.getBlue());

            // CERRAR STREAMS Y SOCKETS
            flujoSalida.close();
            Cliente.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

//colorMedia.getRed() + "," + colorMedia.getGreen() + "," + colorMedia.getBlue()