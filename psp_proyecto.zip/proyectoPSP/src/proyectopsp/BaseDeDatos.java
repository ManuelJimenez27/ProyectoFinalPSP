package proyectopsp;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * @author manuel
 */
public class BaseDeDatos {

    private Connection conexion = null;

    public BaseDeDatos() {

    }

    public boolean acceder(String user, String contra) throws SQLException {
        conectar();
        PreparedStatement ps = conexion.prepareStatement("select * from login where usuario = '" + user + "' and contra = '" + contra + "';");
        ResultSet rs = ps.executeQuery();
        int obtenido = 0;
        while (rs.next()) {
            obtenido++;
        }
        if (obtenido == 1) {
            return true;
        } else {
            return false;
        }
    }

    public String SHA512(String passwordToHash, String salt) {
        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(salt.getBytes(StandardCharsets.UTF_8));
            byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatedPassword;
    }

    private void conectar() throws SQLException {
        conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/psp_proyecto", "root", "");
    }

    private void desconectar() throws SQLException {
        conexion.close();
    }

}
