package App;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 * @author manuel
 */
public class Interface extends JFrame {

    public static JPanel panel;
    public static JLabel etiqueta;
    public static JButton enviar;


    public Interface() {
        initGUI();
    }

    private void initGUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(30, 100);
        setVisible(true);

        panel = new JPanel();
        panel.setLayout(new FlowLayout());
        etiqueta = new JLabel();
        etiqueta.setOpaque(false);
        enviar = new JButton("Enviar");


        panel.add(etiqueta);
        panel.add(enviar);
        this.add(panel);


        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                ProcessBuilder pb = new ProcessBuilder("powershell.exe", "/c", "start src/Papilio_Machaon.jpg");
                try {
                    pb.start();
                } catch (IOException ex) {

                }
            }
        });

        try {
            t.start();
            t.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
