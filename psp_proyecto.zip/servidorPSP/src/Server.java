import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.lang.reflect.Array;
import java.net.*;
import java.util.ArrayList;


public class Server {
    public static void main(String[] args) throws IOException {
        int puerto = 5556;

        System.setProperty("javax.net.ssl.keyStore","src/AlmacenSrv");
        System.setProperty("javax.net.ssl.keyStorePassword","1234567");

        SSLServerSocketFactory sfact = (SSLServerSocketFactory) SSLServerSocketFactory
                .getDefault();
        SSLServerSocket servidorSSL = (SSLServerSocket) sfact
                .createServerSocket(puerto);
        SSLSocket clienteConectado = null;
        DataInputStream flujoEntrada = null;//FLUJO DE ENTRADA DE CLIENTE

        for (int i = 1; i < 5; i++) {
            System.out.println("Servidor iniciado...");
            clienteConectado = (SSLSocket) servidorSSL.accept();
            flujoEntrada = new DataInputStream(clienteConectado.getInputStream());

            // EL CLIENTE ME ENVIA UN MENSAJE
            String recibido = flujoEntrada.readUTF();
            String[] rgb = recibido.split(",");
            Color colorMedioRecibido = new Color(
                    Integer.parseInt(rgb[0]),
                    Integer.parseInt(rgb[1]),
                    Integer.parseInt(rgb[2])
            );
            JFrame fr = new JFrame();
            fr.setSize(new Dimension(300,100));
            JPanel panel = new JPanel();
            panel.setBackground(colorMedioRecibido);
            panel.add(new JLabel("Color Medio recibido: \n "+rgb[0]+" " +rgb[1] + " " +rgb[2]));
            fr.add(panel);
            fr.setVisible(true);
            fr.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        }
        // CERRAR STREAMS Y SOCKETS
        flujoEntrada.close();
        clienteConectado.close();
        servidorSSL.close();
    }
}

/*String[] rgb = mensaje.split(",");
            Color colorMedioRecibido = new Color(
                    Integer.parseInt(rgb[0]),
                    Integer.parseInt(rgb[1]),
                    Integer.parseInt(rgb[2])
            );
            JFrame fr = new JFrame();
            fr.setSize(new Dimension(300,100));
            JPanel panel = new JPanel();
            panel.setBackground(colorMedioRecibido);
            panel.add(new JLabel("Color Medio recibido: \n "+rgb[0]+" " +rgb[1] + " " +rgb[2]));
            fr.add(panel);
            fr.setVisible(true);
            fr.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);*/

/*
 */